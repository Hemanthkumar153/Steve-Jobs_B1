package Java_Exam;
import java.util.Scanner;
public class Pattern2 {
	public static void main(String[] args) {
		int i;
		int j;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the input : ");
		int n = sc.nextInt();
		
		for (i = n; i >= 1; i--) {
	      for (j = 1; j <= i; j++) {
		  System.out.print("*");
		}
		  System.out.println();
	    }
		
		for (i = 1; i <= n; i++) {
		  for (j = 1; j <= i; j++) {
		  System.out.print("*");
	    }
		  System.out.println();
		}
  }
}
		
	


