package Java_Exam;
import java.util.Scanner;

    public class StringProgram {
	public static void main(String[] args) {
		
		int count;
		Scanner sc = new Scanner(System.in) ;
		System.out.println("Enter the String : ");
		String str = sc.next();
		
	
		}
	}

