package Java_Exam;


import java.util.Scanner;                                                  //importing Scanner class 

public class Common {                                                      //Creating a Class
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);                               //Creating a object for Scanner Class
    	System.out.println("Enter the input : ");                          //Taking User Input
    	int input = sc.nextInt();                                          //Storing Input in input Variable
    	
    	if(input%2==0) {                                                   //Checking the Condition
    		System.out.println("Given input is Even :"+input);
    	}
    	else {
    		System.out.println("Given input is Odd :"+input);
    	}
    }
	
}
