package Java_Exam;
import java.util.Scanner;

public class PatternOfCharacters {
public static void main(String[] args) {
	int i;
	int j;
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the input : ");
	int n = sc.nextInt();
	
	for(i=1;i<=n;i++) {
		
		for(j=1;j<=n-i;j++) {
			System.out.print(" ");
		}
		                                
		for (j = 1; j <= i; j++) {
            System.out.print(i + " ");
        }
       
        System.out.println();
	}
}
}
